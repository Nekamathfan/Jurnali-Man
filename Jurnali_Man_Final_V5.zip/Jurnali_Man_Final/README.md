# Журнали Ман

Android application for class attendance and absence reporting.

## Main features
- Automatic present status: only absences are recorded.
- СБ (бо сабаб) and БСБ (бесабаб).
- Green student name for СБ and red student name for БСБ.
- Scrollable student list with large touch-friendly buttons.
- Monthly absence report: СБ, БСБ, total absences.
- Excel-compatible CSV export.
- Class and student management.
- JSON backup and restore.
- Weekly lesson schedule preserved: Mon 7, Tue 6, Wed 7, Thu 6, Fri 7, Sat 3, Sun 0.

## Build
GitHub Actions workflow: `.github/workflows/build.yml`.
