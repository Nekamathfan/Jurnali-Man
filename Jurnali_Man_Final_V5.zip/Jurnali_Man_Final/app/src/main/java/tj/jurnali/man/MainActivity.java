package tj.jurnali.man;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import org.json.*;

public class MainActivity extends Activity {
    private static final String PREFS="journal_prefs", KEY="state", PASSWORD="12345678";

    private final String[] initialNames={
        "АЛШУРОВ АБУБАКР","БАРАТОВА ЗИЁДА","БАРАТОВА МАДИНАБОНУ","БОБОНОЗАРОВА СОЛИҲА","ҒАНИЕВ СУНАТУЛЛО",
        "ЗАРИПОВА СОФИЯ","ИБРОҲИМЗОДА ГЕСУ","ИШИМОВ АБДУСАЛОМ","КАРИМОВ ХУРШЕД","ҚАҲОРОВ МУҲАММАД",
        "МАҲКАМОВ ИДРИС","МИНГБОЕВ БОБУР","МУХТОРОВ МУХАММАДЮСУФ","ОДИЛҶОНОВ ДЖАМОЛИДДИН","ОДИНАЕВ ИЛЁС",
        "ПИРОВ БОБУРҶОН","ПУЛАТОВ КОМРОН","РАҲИМОВ УБАЙДУЛЛО","РУЗИЕВ МУХАММАД","САИДОВ РАБОНИ",
        "САТТАРОВ ОТАҶОН","ТУРСУНОВА ШУКРОНА","УМАРОВ ФАРРУХ","ХАМРОЕВ БАРАКАТУЛЛО","ХОЛБОЕВА МЕҲРИНУШ",
        "ХОЛОВ АБДУЛЛО","ХУДОЁРОВ ҲАСАН","ШЕРОВ САИДАҲМАДХОН","БЕРДИМУРАТОВ АЗИМҶОН","НАЗАРОВА ОСИЁ"
    };

    private JSONObject state;
    private String currentClassId;
    private String selectedDate;
    private int selectedLesson=1;

    private LinearLayout root, studentsBox, bottomNav;
    private TextView dateView, lessonView, classView, statsView;
    private ArrayList<String> classIds=new ArrayList<>();

    private final int navy=Color.rgb(9,48,73);
    private final int navy2=Color.rgb(11,58,88);
    private final int blue=Color.rgb(18,139,220);
    private final int green=Color.rgb(21,153,84);
    private final int red=Color.rgb(220,39,58);
    private final int text=Color.rgb(18,43,67);
    private final int muted=Color.rgb(100,113,126);
    private final int bg=Color.rgb(244,248,252);
    private final int border=Color.rgb(216,226,235);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        loadState();
        selectedDate=today();
        showLogin();
    }

    private String today(){return new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new Date());}
    private String keyDate(){return selectedDate+"|"+selectedLesson;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}

    private void loadState(){
        String s=getSharedPreferences(PREFS,0).getString(KEY,null);
        try{state=s!=null?new JSONObject(s):createInitial();}catch(Exception e){state=createInitial();}
        try{currentClassId=state.getString("currentClass");}catch(Exception e){currentClassId=firstClassId();}
        save();
    }

    private JSONObject createInitial(){
        JSONObject st=new JSONObject();
        try{
            JSONArray classes=new JSONArray(); JSONObject c=new JSONObject(); String cid=id();
            c.put("id",cid); c.put("name","8 «В»"); JSONArray ss=new JSONArray();
            for(String n:initialNames){JSONObject x=new JSONObject();x.put("id",id());x.put("name",n);ss.put(x);}
            c.put("students",ss); classes.put(c); st.put("classes",classes);
            st.put("attendance",new JSONObject()); st.put("currentClass",cid);
        }catch(Exception ignored){}
        return st;
    }

    private String id(){return System.currentTimeMillis()+"_"+UUID.randomUUID().toString().substring(0,8);}
    private void save(){getSharedPreferences(PREFS,0).edit().putString(KEY,state.toString()).apply();}
    private String firstClassId(){try{return state.getJSONArray("classes").getJSONObject(0).getString("id");}catch(Exception e){return "";}}
    private JSONObject currentClass(){
        try{JSONArray a=state.getJSONArray("classes");for(int i=0;i<a.length();i++){JSONObject c=a.getJSONObject(i);if(c.getString("id").equals(currentClassId))return c;}}catch(Exception ignored){}
        return null;
    }

    private GradientDrawable rounded(int color,float radius){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;
    }
    private GradientDrawable outlined(int fill,int stroke,float radius){
        GradientDrawable g=rounded(fill,radius);g.setStroke(dp(1.3f),stroke);return g;
    }
    private TextView tv(String s,float size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}

    private void showLogin(){
        LinearLayout box=vertical();box.setPadding(dp(20),dp(8),dp(20),dp(4));
        TextView title=tv("ЛБХБ ТУРСУНЗОДА",23,navy,true);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView sub=tv("Барои идома паролро ворид кунед",15,muted,false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(36)));
        final EditText pass=new EditText(this);pass.setInputType(0x81);pass.setHint("Парол");box.addView(pass,new LinearLayout.LayoutParams(-1,dp(52)));
        final AlertDialog d=new AlertDialog.Builder(this).setView(box).setCancelable(false).setPositiveButton("Даромадан",null).setNegativeButton("Баромадан",(x,w)->finish()).create();
        d.setOnShowListener(x->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(PASSWORD.equals(pass.getText().toString())){d.dismiss();buildMain();}else pass.setError("Парол нодуруст аст");
        });});
        d.show();
    }

    private void buildMain(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(navy);
        root.setPadding(0,0,0,0);setContentView(root);

        if(android.os.Build.VERSION.SDK_INT>=23){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                int top=insets.getSystemWindowInsetTop();int bottom=insets.getSystemWindowInsetBottom();
                v.setPadding(0,top,0,bottom);return insets;
            });
            root.requestApplyInsets();
        }

        LinearLayout header=vertical();header.setPadding(dp(18),dp(7),dp(12),dp(7));header.setBackgroundColor(navy);
        TextView title=tv("🎓  ЛБХБ ТУРСУНЗОДА",22,Color.WHITE,true);header.addView(title,new LinearLayout.LayoutParams(-1,dp(60)));
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(68)));

        LinearLayout main=vertical();main.setBackgroundColor(bg);root.addView(main,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout controls=vertical();controls.setPadding(dp(10),dp(8),dp(10),dp(5));main.addView(controls,new LinearLayout.LayoutParams(-1,dp(128)));

        LinearLayout top=row();
        classView=cardText("Синф:  "+className(),19,text,true);classView.setOnClickListener(v->manageClasses());
        dateView=cardText("📅  "+selectedDate,18,text,true);dateView.setOnClickListener(v->pickDate());
        lessonView=cardText("Дарс:  Соати "+selectedLesson,18,text,true);lessonView.setOnClickListener(v->showLessonPicker());
        addWeighted(top,classView,1,0,5);addWeighted(top,dateView,1,5,5);addWeighted(top,lessonView,1,5,0);controls.addView(top,new LinearLayout.LayoutParams(-1,dp(55)));

        LinearLayout stats=vertical();stats.setGravity(Gravity.CENTER_VERTICAL);stats.setPadding(dp(12),0,dp(12),0);stats.setBackground(outlined(Color.WHITE,border,18));
        statsView=tv("",15,text,true);stats.addView(statsView,new LinearLayout.LayoutParams(-1,dp(48)));controls.addView(stats,new LinearLayout.LayoutParams(-1,dp(56)));

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);
        studentsBox=vertical();studentsBox.setPadding(dp(10),dp(2),dp(10),dp(10));scroll.addView(studentsBox,new ScrollView.LayoutParams(-1,-2));
        main.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        bottomNav=vertical();bottomNav.setOrientation(LinearLayout.HORIZONTAL);bottomNav.setGravity(Gravity.CENTER);bottomNav.setPadding(dp(6),dp(6),dp(6),dp(6));bottomNav.setBackground(rounded(navy2,26));
        root.addView(bottomNav,new LinearLayout.LayoutParams(-1,dp(88)));

        addBottom("✏", "Қайд", true, v->showAttendance());
        addBottom("▥", "Ҳисобот", false, v->monthlyReport());
        addBottom("▣", "Excel", false, v->exportExcel());
        addBottom("▤", "Backup", false, v->backup());
        addBottom("♻", "Restore", false, v->restore());

        setupClasses();updateLessonView();refresh();
    }

    private String className(){JSONObject c=currentClass();return c==null?"8 «В»":c.optString("name","8 «В»");}
    private void addWeighted(LinearLayout parent,View child,float weight,int left,int right){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,weight);p.setMargins(dp(left),0,dp(right),0);parent.addView(child,p);}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView cardText(String s,float size,int color,boolean bold){TextView t=tv(s,size,color,bold);t.setPadding(dp(14),0,dp(10),0);t.setBackground(outlined(Color.WHITE,border,17));return t;}
    private void setupClasses(){
        classIds.clear();try{JSONArray a=state.getJSONArray("classes");for(int i=0;i<a.length();i++)classIds.add(a.getJSONObject(i).getString("id"));}catch(Exception ignored){}
    }

    private int lessonsFor(String ddmmyyyy){
        try{Date d=new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(ddmmyyyy);Calendar c=Calendar.getInstance();c.setTime(d);int w=c.get(Calendar.DAY_OF_WEEK);
            if(w==Calendar.SUNDAY)return 0;if(w==Calendar.SATURDAY)return 3;if(w==Calendar.TUESDAY||w==Calendar.THURSDAY)return 6;return 7;
        }catch(Exception e){return 7;}
    }

    private void updateLessonView(){
        int n=lessonsFor(selectedDate);if(n==0)selectedLesson=0;else if(selectedLesson<1||selectedLesson>n)selectedLesson=1;
        lessonView.setText(n==0?"Дарс:  Якшанбе":("Дарс:  Соати "+selectedLesson));
    }

    private void showLessonPicker(){
        int n=lessonsFor(selectedDate);if(n==0){toast("Якшанбе — дарс нест");return;}
        String[] a=new String[n];for(int i=0;i<n;i++)a[i]="Соати "+(i+1);
        new AlertDialog.Builder(this).setTitle("Интихоби дарс").setSingleChoiceItems(a,selectedLesson-1,(d,w)->{selectedLesson=w+1;d.dismiss();updateLessonView();refresh();}).setNegativeButton("Бекор",null).show();
    }

    private void refresh(){
        if(studentsBox==null)return;
        dateView.setText("📅  "+selectedDate);
        updateLessonView();
        studentsBox.removeAllViews();JSONObject c=currentClass();if(c==null)return;
        try{JSONArray ss=c.getJSONArray("students");int absent=0;for(int i=0;i<ss.length();i++){JSONObject s=ss.getJSONObject(i);String status=getStatus(s.optString("id"));if("SB".equals(status)||"BSB".equals(status))absent++;addStudentRow(s,i+1);}
            int total=ss.length(),present=Math.max(0,total-absent);statsView.setText("👥  Ҳамагӣ: "+total+"     🟢  Ҳозир: "+present+"     🔴  Ғоиб: "+absent);
        }catch(Exception ignored){}
    }

    private void addStudentRow(JSONObject st,int num){
        final String sid=st.optString("id"),name=st.optString("name");String status=getStatus(sid);
        LinearLayout r=row();r.setPadding(dp(7),dp(3),dp(5),dp(3));r.setBackground(outlined(Color.WHITE,border,15));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(56));rp.setMargins(0,dp(3),0,dp(3));studentsBox.addView(r,rp);

        TextView no=tv(String.valueOf(num),16,muted,true);no.setGravity(Gravity.CENTER);r.addView(no,new LinearLayout.LayoutParams(dp(38),-1));
        TextView nm=tv(name,17,text,true);nm.setSingleLine(true);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);r.addView(nm,new LinearLayout.LayoutParams(0,-1,1));

        Button sb=absenceButton("СБ",green);Button bsb=absenceButton("БСБ",red);
        LinearLayout.LayoutParams bp1=new LinearLayout.LayoutParams(dp(78),dp(50));bp1.setMargins(dp(3),0,dp(4),0);r.addView(sb,bp1);
        LinearLayout.LayoutParams bp2=new LinearLayout.LayoutParams(dp(82),dp(50));r.addView(bsb,bp2);

        applyStatusStyle(nm,sb,bsb,status);
        sb.setOnClickListener(v->{if("SB".equals(getStatus(sid))){clearStatus(sid);refresh();}else setSB(sid);});
        bsb.setOnClickListener(v->{if("BSB".equals(getStatus(sid))){clearStatus(sid);refresh();}else{setBSB(sid);refresh();}});
    }

    private Button absenceButton(String label,int color){
        Button b=new Button(this);b.setText(label);b.setTextSize(16);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setAllCaps(false);b.setTextColor(color);b.setPadding(0,0,0,0);b.setMinHeight(0);b.setMinWidth(0);b.setBackground(outlined(Color.WHITE,color,14));return b;
    }

    private void applyStatusStyle(TextView nm,Button sb,Button bsb,String status){
        if("SB".equals(status)){
            nm.setTextColor(green);nm.setBackground(rounded(Color.rgb(229,248,238),10));
            sb.setTextColor(Color.WHITE);sb.setBackground(rounded(green,14));bsb.setTextColor(red);bsb.setBackground(outlined(Color.WHITE,red,14));
        }else if("BSB".equals(status)){
            nm.setTextColor(red);nm.setBackground(rounded(Color.rgb(255,234,237),10));
            bsb.setTextColor(Color.WHITE);bsb.setBackground(rounded(red,14));sb.setTextColor(green);sb.setBackground(outlined(Color.WHITE,green,14));
        }else{
            nm.setTextColor(text);nm.setBackgroundColor(Color.TRANSPARENT);
            sb.setTextColor(green);sb.setBackground(outlined(Color.WHITE,green,14));bsb.setTextColor(red);bsb.setBackground(outlined(Color.WHITE,red,14));
        }
    }

    private JSONObject attendance(){
        try{return state.getJSONObject("attendance");}catch(Exception e){try{JSONObject a=new JSONObject();state.put("attendance",a);return a;}catch(Exception x){return new JSONObject();}}
    }
    private String attKey(String sid){return currentClassId+"|"+keyDate()+"|"+sid;}
    private String getStatus(String sid){
        String raw=attendance().optString(attKey(sid),"");if(raw.isEmpty())return "";
        try{return new JSONObject(raw).optString("status","");}catch(Exception e){return "";}
    }
    private void clearStatus(String sid){attendance().remove(attKey(sid));save();}
    private void setBSB(String sid){try{JSONObject x=new JSONObject();x.put("status","BSB");x.put("reason","");attendance().put(attKey(sid),x.toString());save();}catch(Exception ignored){}}
    private void setSB(String sid){
        try{JSONObject x=new JSONObject();x.put("status","SB");x.put("reason","");attendance().put(attKey(sid),x.toString());save();refresh();}catch(Exception ignored){}
    }

    private void pickDate(){
        Calendar c=Calendar.getInstance();try{c.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}
        new DatePickerDialog(this,(v,y,m,d)->{selectedDate=String.format(Locale.getDefault(),"%02d.%02d.%04d",d,m+1,y);selectedLesson=1;updateLessonView();refresh();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void addBottom(String icon,String label,boolean selected,View.OnClickListener listener){
        LinearLayout item=vertical();item.setGravity(Gravity.CENTER);item.setPadding(dp(2),0,dp(2),0);item.setOnClickListener(listener);
        TextView i=tv(icon,27,Color.WHITE,true);i.setGravity(Gravity.CENTER);TextView l=tv(label,14,Color.WHITE,true);l.setGravity(Gravity.CENTER);
        item.addView(i,new LinearLayout.LayoutParams(-1,dp(38)));item.addView(l,new LinearLayout.LayoutParams(-1,dp(30)));
        if(selected){item.setBackground(rounded(Color.rgb(14,112,184),30));i.setTextColor(Color.WHITE);l.setTextColor(Color.WHITE);}
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.setMargins(dp(3),0,dp(3),0);bottomNav.addView(item,p);
    }

    private void showAttendance(){toast("Қайд: ғоибҳоро бо СБ ё БСБ интихоб кунед");}

    private void manageClasses(){
        LinearLayout l=vertical();l.setPadding(dp(8),dp(4),dp(8),dp(4));JSONArray a;try{a=state.getJSONArray("classes");}catch(Exception e){return;}
        for(int i=0;i<a.length();i++){
            final JSONObject c=a.optJSONObject(i);if(c==null)continue;LinearLayout r=row();TextView n=tv(c.optString("name"),17,text,true);r.addView(n,new LinearLayout.LayoutParams(0,dp(52),1));
            Button open=smallButton("Кушодан",blue),del=smallButton("Нест",red);r.addView(open,new LinearLayout.LayoutParams(dp(90),dp(48)));r.addView(del,new LinearLayout.LayoutParams(dp(70),dp(48)));l.addView(r);
            open.setOnClickListener(v->{currentClassId=c.optString("id");try{state.put("currentClass",currentClassId);}catch(Exception ignored){}save();buildMain();});del.setOnClickListener(v->deleteClass(c.optString("id")));
        }
        Button add=smallButton("＋ Иловаи синф",green);l.addView(add);add.setOnClickListener(v->addClassDialog());
        Button excel=smallButton("📊  Ворид аз Excel",blue);l.addView(excel);excel.setOnClickListener(v->importStudentListFromFile());
        new AlertDialog.Builder(this).setTitle("Синфҳо").setView(l).setNegativeButton("Пӯшидан",null).show();
    }

    private void importStudentListFromFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","text/csv","text/comma-separated-values","application/vnd.ms-excel","text/plain"});startActivityForResult(i,13);
    }


    private void importStudentsFromText(String textData){
        if(textData==null)return;
        ArrayList<String> names=new ArrayList<>();
        String[] lines=textData.replace('\r','\n').split("\\n+");
        for(String line:lines){
            String x=line.trim().replaceAll("^\\s*[-–—•]+\\s*","").trim();
            if(x.isEmpty())continue;
            x=x.replaceAll("^\\s*\\d+[.)]\\s*","").trim();
            if(x.isEmpty()||isHeader(x))continue;
            if(x.contains("\t")){
                String[] cells=x.split("\\t");
                if(cells.length>1 && !cells[1].trim().isEmpty()) x=cells[1].trim();
            }else if(x.contains(";")){
                String[] cells=x.split(";");
                if(cells.length>1 && !cells[1].trim().isEmpty()) x=cells[1].trim();
            }else if(x.contains(",")){
                String[] cells=x.split(",");
                if(cells.length>1 && !cells[1].trim().isEmpty()) x=cells[1].trim();
            }
            x=x.replaceAll("\\s{2,}"," ").trim();
            if(isReasonableStudentName(x))names.add(x);
        }
        showImportedNames(names,"Рӯйхати ёфтшуда");
    }

    private boolean isHeader(String x){String q=x.toLowerCase(Locale.ROOT);return q.equals("ном")||q.contains("ному насаб")||q.contains("хонанда")||q.equals("name")||q.contains("fio")||q.equals("фио");}
    private boolean isReasonableStudentName(String x){
        if(x.length()<3||x.length()>100)return false;
        String letters=x.replaceAll("[^\\p{L}]","");
        return letters.length()>=3;
    }

    private void showImportedNames(ArrayList<String> names,String title){
        if(names.isEmpty()){toast("Дар файл рӯйхати хонандагон ёфт нашуд");return;}
        LinearLayout box=vertical();box.setPadding(dp(8),dp(4),dp(8),dp(4));
        TextView info=tv("Ёфт шуд: "+names.size()+" хонанда. Номҳоро санҷед ва тасдиқ кунед.",15,text,true);box.addView(info,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText edit=new EditText(this);edit.setText(joinNames(names));edit.setGravity(Gravity.TOP);edit.setSingleLine(false);edit.setInputType(0x00004001);box.addView(edit,new LinearLayout.LayoutParams(-1,dp(300)));
        new AlertDialog.Builder(this).setTitle(title).setView(box).setPositiveButton("Илова кардан",(d,w)->{
            ArrayList<String> checked=parseNames(edit.getText().toString());addImportedStudents(checked);
        }).setNegativeButton("Бекор",null).show();
    }
    private String joinNames(ArrayList<String> a){StringBuilder b=new StringBuilder();for(String n:a)b.append(n).append("\\n");return b.toString().trim();}
    private ArrayList<String> parseNames(String s){ArrayList<String> a=new ArrayList<>();for(String line:s.split("\\n+")){String x=line.trim().replaceAll("^\\s*\\d+[.)]\\s*","").trim();if(isReasonableStudentName(x)&&!isHeader(x))a.add(x);}return a;}
    private void addImportedStudents(ArrayList<String> names){
        JSONObject c=currentClass();if(c==null||names.isEmpty())return;
        try{JSONArray arr=c.getJSONArray("students");HashSet<String> existing=new HashSet<>();for(int i=0;i<arr.length();i++)existing.add(arr.getJSONObject(i).optString("name").trim().toLowerCase(Locale.ROOT));int added=0;
            for(String n:names){String k=n.trim().toLowerCase(Locale.ROOT);if(k.isEmpty()||existing.contains(k))continue;JSONObject st=new JSONObject();st.put("id",id());st.put("name",n.trim());arr.put(st);existing.add(k);added++;}
            save();refresh();toast("Илова шуд: "+added+" хонанда");
        }catch(Exception ignored){toast("Хатогӣ ҳангоми иловаи рӯйхат");}
    }

    private void readImportedFile(Uri uri){
        try{String name=uri.toString().toLowerCase(Locale.ROOT);InputStream in=getContentResolver().openInputStream(uri);if(in==null)throw new IOException();
            ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();byte[] data=out.toByteArray();
            String result;
            if(isXlsx(data)){result=parseXlsx(data);}else result=new String(data,"UTF-8");
            importStudentsFromText(result);
        }catch(Exception e){toast("Файли Excel/CSV хонда нашуд");}
    }
    private boolean isXlsx(byte[] data){return data.length>4 && data[0]=='P'&&data[1]=='K'&&data[2]==3&&data[3]==4;}
    private String parseXlsx(byte[] data)throws Exception{
        HashMap<String,String> shared=new HashMap<>();String sheet=null;
        ZipInputStream z=new ZipInputStream(new ByteArrayInputStream(data));ZipEntry e;while((e=z.getNextEntry())!=null){if("xl/sharedStrings.xml".equals(e.getName()))shared=parseSharedStrings(z);else if(e.getName().startsWith("xl/worksheets/sheet")&&e.getName().endsWith(".xml")&&sheet==null)sheet=readAll(z);z.closeEntry();}z.close();
        if(sheet==null)throw new IOException();return parseSheetXml(sheet,shared);
    }
    private String readAll(InputStream in)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] q=new byte[8192];int n;while((n=in.read(q))>0)b.write(q,0,n);return new String(b.toByteArray(),"UTF-8");}
    private HashMap<String,String> parseSharedStrings(InputStream in)throws Exception{
        HashMap<String,String> map=new HashMap<>();XmlPullParser p=XmlPullParserFactory.newInstance().newPullParser();p.setInput(in,"UTF-8");int idx=0;StringBuilder textBuf=new StringBuilder();boolean inSi=false;for(int ev=p.getEventType();ev!=XmlPullParser.END_DOCUMENT;ev=p.next()){
            if(ev==XmlPullParser.START_TAG&&"si".equals(p.getName())){inSi=true;textBuf.setLength(0);}else if(ev==XmlPullParser.TEXT&&inSi){textBuf.append(p.getText());}else if(ev==XmlPullParser.END_TAG&&"si".equals(p.getName())){map.put(String.valueOf(idx++),textBuf.toString());inSi=false;}}
        return map;
    }
    private String parseSheetXml(String xml,HashMap<String,String> shared)throws Exception{
        XmlPullParser p=XmlPullParserFactory.newInstance().newPullParser();p.setInput(new StringReader(xml));StringBuilder out=new StringBuilder();String cellRef="",cellType="",value="";int row=0;boolean inV=false,inT=false;
        for(int ev=p.getEventType();ev!=XmlPullParser.END_DOCUMENT;ev=p.next()){
            if(ev==XmlPullParser.START_TAG){String tag=p.getName();if("row".equals(tag)){row++;}else if("c".equals(tag)){cellRef=p.getAttributeValue(null,"r");cellType=p.getAttributeValue(null,"t");value="";}else if("v".equals(tag)||"t".equals(tag)){inV="v".equals(tag);inT="t".equals(tag);}}
            else if(ev==XmlPullParser.TEXT&&(inV||inT)){value+=p.getText();}
            else if(ev==XmlPullParser.END_TAG){String tag=p.getName();if("v".equals(tag)||"t".equals(tag)){inV=false;inT=false;}else if("c".equals(tag)){String val=value;if("s".equals(cellType))val=shared.getOrDefault(value,value);int col=columnIndex(cellRef);if(col<=2&&val!=null&&!val.isEmpty()){if(col==1)out.append(val.trim());else if(col==2)out.append("\t").append(val.trim());} }else if("row".equals(tag)){out.append("\n");}}
        }
        return out.toString();
    }
    private int columnIndex(String ref){if(ref==null||ref.isEmpty())return 999;int n=0;for(int i=0;i<ref.length()&&Character.isLetter(ref.charAt(i));i++)n=n*26+(Character.toUpperCase(ref.charAt(i))-'A'+1);return n;}

    private Button smallButton(String s,int color){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(rounded(color,12));return b;}
    private void deleteClass(String cid){
        try{JSONArray a=state.getJSONArray("classes");if(a.length()<=1){toast("Камаш як синф бояд бошад");return;}
            new AlertDialog.Builder(this).setTitle("Нест кардани синф?").setMessage("Ҳамаи маълумоти ҳамин синф нест мешавад.").setPositiveButton("Нест",(d,w)->{for(int i=0;i<a.length();i++)if(a.optJSONObject(i).optString("id").equals(cid)){a.remove(i);break;}if(currentClassId.equals(cid))currentClassId=a.optJSONObject(0).optString("id");try{state.put("currentClass",currentClassId);}catch(Exception ignored){}save();buildMain();}).setNegativeButton("Бекор",null).show();
        }catch(Exception ignored){}
    }
    private void addClassDialog(){
        final EditText e=new EditText(this);e.setHint("Масалан: 9 «А»");
        new AlertDialog.Builder(this).setTitle("Синфи нав").setView(e).setPositiveButton("Илова",(d,w)->{String n=e.getText().toString().trim();if(n.isEmpty())return;try{JSONObject c=new JSONObject();String cid=id();c.put("id",cid);c.put("name",n);c.put("students",new JSONArray());state.getJSONArray("classes").put(c);currentClassId=cid;state.put("currentClass",cid);save();buildMain();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();
    }

    private void manageStudents(){
        JSONObject c=currentClass();if(c==null)return;LinearLayout l=vertical();l.setPadding(dp(8),dp(4),dp(8),dp(4));
        try{JSONArray a=c.getJSONArray("students");for(int i=0;i<a.length();i++){JSONObject s=a.getJSONObject(i);final int idx=i;LinearLayout r=row();r.addView(tv((i+1)+". "+s.optString("name"),15,text,false),new LinearLayout.LayoutParams(0,dp(50),1));Button edit=smallButton("Таҳрир",blue),del=smallButton("Нест",red);r.addView(edit,new LinearLayout.LayoutParams(dp(78),dp(46)));r.addView(del,new LinearLayout.LayoutParams(dp(70),dp(46)));l.addView(r);edit.setOnClickListener(v->editStudent(idx));del.setOnClickListener(v->deleteStudent(idx));}}catch(Exception ignored){}
        Button add=smallButton("＋ Иловаи хонанда",green);l.addView(add);add.setOnClickListener(v->addStudent());ScrollView sv=new ScrollView(this);sv.addView(l);new AlertDialog.Builder(this).setTitle("Хонандагони "+c.optString("name")).setView(sv).setPositiveButton("Пӯшидан",null).setNeutralButton("Синфро холӣ кардан",(d,w)->clearStudents()).show();
    }
    private void addStudent(){final EditText e=new EditText(this);e.setHint("Ному насаб");new AlertDialog.Builder(this).setTitle("Хонандаи нав").setView(e).setPositiveButton("Илова",(d,w)->{try{String n=e.getText().toString().trim();if(n.isEmpty())return;JSONObject s=new JSONObject();s.put("id",id());s.put("name",n);currentClass().getJSONArray("students").put(s);save();refresh();manageStudents();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}
    private void editStudent(int idx){final EditText e=new EditText(this);try{e.setText(currentClass().getJSONArray("students").getJSONObject(idx).optString("name"));}catch(Exception ignored){}new AlertDialog.Builder(this).setTitle("Таҳрири ном").setView(e).setPositiveButton("Захира",(d,w)->{try{String n=e.getText().toString().trim();if(!n.isEmpty()){currentClass().getJSONArray("students").getJSONObject(idx).put("name",n);save();refresh();manageStudents();}}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}
    private void deleteStudent(int idx){new AlertDialog.Builder(this).setTitle("Нест кардани хонанда?").setMessage("Давомоти дигар хонандагон тағйир намеёбад.").setPositiveButton("Нест",(d,w)->{try{currentClass().getJSONArray("students").remove(idx);save();refresh();manageStudents();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}
    private void clearStudents(){new AlertDialog.Builder(this).setTitle("Рӯйхатро холӣ кунам?").setMessage("Номҳои синфи ҷорӣ нест мешаванд.").setPositiveButton("Холӣ кун",(d,w)->{try{currentClass().put("students",new JSONArray());save();refresh();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}

    private void monthlyReport(){
        Calendar now=Calendar.getInstance();try{now.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}
        int month=now.get(Calendar.MONTH),year=now.get(Calendar.YEAR);String[] months={"Январ","Феврал","Март","Апрел","Май","Июн","Июл","Август","Сентябр","Октябр","Ноябр","Декабр"};
        LinearLayout l=vertical();l.setPadding(dp(12),dp(8),dp(12),dp(8));l.addView(tv("Синф: "+className()+"\nМоҳ: "+months[month]+" "+year,17,text,true),new LinearLayout.LayoutParams(-1,dp(60)));StringBuilder out=new StringBuilder();
        try{Calendar c=Calendar.getInstance();int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);JSONArray ss=currentClass().getJSONArray("students");int totalSB=0,totalBSB=0;
            for(int i=0;i<ss.length();i++){JSONObject s=ss.getJSONObject(i);int sb=0,bsb=0;for(int d=1;d<=days;d++){c.set(year,month,d);int w=c.get(Calendar.DAY_OF_WEEK);int n=(w==Calendar.SUNDAY)?0:(w==Calendar.SATURDAY?3:((w==Calendar.TUESDAY||w==Calendar.THURSDAY)?6:7));for(int les=1;les<=n;les++){String date=String.format(Locale.getDefault(),"%02d.%02d.%04d",d,month+1,year);String raw=attendance().optString(currentClassId+"|"+date+"|"+les+"|"+s.optString("id"));if(raw.isEmpty())continue;try{String st=new JSONObject(raw).optString("status");if("SB".equals(st))sb++;else if("BSB".equals(st))bsb++;}catch(Exception ignored){}}}totalSB+=sb;totalBSB+=bsb;out.append(String.format(Locale.getDefault(),"%2d. %-28s  СБ: %2d   БСБ: %2d   Ҳамагӣ: %2d\n",i+1,s.optString("name"),sb,bsb,sb+bsb));}
            out.append("\nҲамагӣ: СБ = ").append(totalSB).append("   БСБ = ").append(totalBSB).append("   Ғоибӣ = ").append(totalSB+totalBSB);
        }catch(Exception ignored){}
        TextView body=tv(out.toString(),14,text,false);body.setPadding(dp(6),dp(8),dp(6),dp(8));ScrollView sv=new ScrollView(this);sv.addView(body);l.addView(sv,new LinearLayout.LayoutParams(-1,dp(420)));new AlertDialog.Builder(this).setTitle("ҲИСОБОТИ ҒОИБӢ").setView(l).setPositiveButton("Пӯшидан",null).show();
    }

    private void exportExcel(){
        StringBuilder csv=new StringBuilder("№,Хонанда,СБ,БСБ,Ҳамагӣ\n");
        Calendar now=Calendar.getInstance();try{now.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}
        int month=now.get(Calendar.MONTH),year=now.get(Calendar.YEAR);
        try{JSONArray ss=currentClass().getJSONArray("students");Calendar c=Calendar.getInstance();int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);
            for(int i=0;i<ss.length();i++){JSONObject s=ss.getJSONObject(i);int sb=0,bsb=0;for(int d=1;d<=days;d++){c.set(year,month,d);int w=c.get(Calendar.DAY_OF_WEEK);int n=(w==Calendar.SUNDAY)?0:(w==Calendar.SATURDAY?3:((w==Calendar.TUESDAY||w==Calendar.THURSDAY)?6:7));for(int les=1;les<=n;les++){String date=String.format(Locale.getDefault(),"%02d.%02d.%04d",d,month+1,year);String raw=attendance().optString(currentClassId+"|"+date+"|"+les+"|"+s.optString("id"));if(raw.isEmpty())continue;try{String st=new JSONObject(raw).optString("status");if("SB".equals(st))sb++;else if("BSB".equals(st))bsb++;}catch(Exception ignored){}}}csv.append(i+1).append(",\"").append(s.optString("name").replace("\"","\"\"")).append("\",").append(sb).append(",").append(bsb).append(",").append(sb+bsb).append("\n");}
        }catch(Exception ignored){}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"Jurnali_Man_Hisobot.csv");i.putExtra("csv_data",csv.toString());startActivityForResult(i,12);
    }

    private void backup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Jurnali_Man_Backup.json");startActivityForResult(i,10);}
    private void restore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,11);}

    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data);if(c!=RESULT_OK||data==null)return;
        try{
            if(r==10){writeBytes(data.getData(),state.toString(2).getBytes("UTF-8"));toast("Нусха захира шуд");}
            else if(r==12){String csv=createExcelCsv();writeBytes(data.getData(),("\uFEFF"+csv).getBytes("UTF-8"));toast("Ҳисобот ба Excel омода шуд");}
            else if(r==13){readImportedFile(data.getData());}
            else if(r==11){InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)b.write(buf,0,n);in.close();JSONObject x=new JSONObject(new String(b.toByteArray(),"UTF-8"));if(!x.has("classes")||!x.has("attendance"))throw new Exception();state=x;currentClassId=state.optString("currentClass",firstClassId());save();buildMain();toast("Маълумот барқарор шуд");}
        }catch(Exception e){toast("Файл дуруст нест");}
    }
    private void writeBytes(Uri uri,byte[] data)throws Exception{OutputStream o=getContentResolver().openOutputStream(uri);if(o==null)throw new IOException();o.write(data);o.close();}
    private String createExcelCsv(){
        StringBuilder csv=new StringBuilder("№,Хонанда,СБ,БСБ,Ҳамагӣ\n");Calendar now=Calendar.getInstance();try{now.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}int month=now.get(Calendar.MONTH),year=now.get(Calendar.YEAR);
        try{JSONArray ss=currentClass().getJSONArray("students");Calendar c=Calendar.getInstance();int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);for(int i=0;i<ss.length();i++){JSONObject s=ss.getJSONObject(i);int sb=0,bsb=0;for(int d=1;d<=days;d++){c.set(year,month,d);int w=c.get(Calendar.DAY_OF_WEEK);int n=(w==Calendar.SUNDAY)?0:(w==Calendar.SATURDAY?3:((w==Calendar.TUESDAY||w==Calendar.THURSDAY)?6:7));for(int les=1;les<=n;les++){String date=String.format(Locale.getDefault(),"%02d.%02d.%04d",d,month+1,year);String raw=attendance().optString(currentClassId+"|"+date+"|"+les+"|"+s.optString("id"));if(raw.isEmpty())continue;try{String st=new JSONObject(raw).optString("status");if("SB".equals(st))sb++;else if("BSB".equals(st))bsb++;}catch(Exception ignored){}}}csv.append(i+1).append(",\"").append(s.optString("name").replace("\"","\"\"")).append("\",").append(sb).append(",").append(bsb).append(",").append(sb+bsb).append("\n");}}catch(Exception ignored){}return csv.toString();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
