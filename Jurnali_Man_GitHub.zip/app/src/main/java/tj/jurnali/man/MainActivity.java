package tj.jurnali.man;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    private static final String PREFS="journal_prefs", KEY="state", PASSWORD="12345678";
    private final String[] initialNames={
        "АЛШУРОВ АБУБАКР","БАРАТОВА ЗИЁДА","БАРАТОВА МАДИНАБОНУ","БОБОНОЗАРОВА СОЛИҲА","ҒАНИЕВ СУНАТУЛЛО",
        "ЗАРИПОВА СОФИЯ","ИБРОҲИМЗОДА ГЕСУ","ИШИМОВ АБДУСАЛОМ","КАРИМОВ ХУРШЕД","ҚАҲОРОВ МУҲАММАД",
        "МАҲКАМОВ ИДРИС","МИНГБОЕВ БОБУР","МУХТОРОВ МУХАММАДЮСУФ","ОДИЛҶОНОВ ДЖАМОЛИДДИН","ОДИНАЕВ ИЛЁС",
        "ПИРОВ БОБУРҶОН","ПУЛАТОВ КОМРОН","РАҲИМОВ УБАЙДУЛЛО","РУЗИЕВ МУХАММАД","САИДОВ РАБОНИ",
        "САТТАРОВ ОТАҶОН","ТУРСУНОВА ШУКРОНА","УМАРОВ ФАРРУХ","ХАМРОЕВ БАРАКАТУЛЛО","ХОЛБОЕВА МЕҲРИНУШ",
        "ХОЛОВ АБДУЛЛО","ХУДОЁРОВ ҲАСАН","ШЕРОВ САИДАҲМАДХОН","БЕРДИМУРАТОВ АЗИМҶОН","НАЗАРОВА ОСИЁ"
    };
    private JSONObject state; private String currentClassId; private String selectedDate; private int selectedLesson=1;
    private LinearLayout root, studentsBox; private Spinner classSpinner, lessonSpinner; private TextView dateView, emptyView;
    private ArrayList<String> classIds=new ArrayList<>();
    private int navy=Color.rgb(18,38,58), blue=Color.rgb(30,136,229), red=Color.rgb(211,47,47), green=Color.rgb(46,125,50), light=Color.rgb(245,248,252);

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(navy); loadState(); selectedDate=today(); showLogin();}
    private String today(){return new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new Date());}
    private String keyDate(){return selectedDate+"|"+selectedLesson;}

    private void loadState(){
        String s=getSharedPreferences(PREFS,0).getString(KEY,null);
        try { if(s!=null) state=new JSONObject(s); else state=createInitial(); } catch(Exception e){state=createInitial();}
        save();
        try{ currentClassId=state.getString("currentClass"); }catch(Exception e){currentClassId=firstClassId();}
    }
    private JSONObject createInitial(){
        JSONObject st=new JSONObject(); JSONArray classes=new JSONArray(); JSONObject c=new JSONObject();
        try{
            String cid=id(); c.put("id",cid); c.put("name","8 «В»"); JSONArray ss=new JSONArray();
            for(String n:initialNames){JSONObject x=new JSONObject();x.put("id",id());x.put("name",n);ss.put(x);} c.put("students",ss); classes.put(c); st.put("classes",classes);st.put("attendance",new JSONObject());st.put("currentClass",cid);
        }catch(Exception ignored){} return st;
    }
    private String id(){return System.currentTimeMillis()+"_"+UUID.randomUUID().toString().substring(0,8);}
    private void save(){getSharedPreferences(PREFS,0).edit().putString(KEY,state.toString()).apply();}
    private String firstClassId(){try{return state.getJSONArray("classes").getJSONObject(0).getString("id");}catch(Exception e){return "";}}
    private JSONObject currentClass(){try{JSONArray a=state.getJSONArray("classes");for(int i=0;i<a.length();i++){JSONObject c=a.getJSONObject(i);if(c.getString("id").equals(currentClassId))return c;}}catch(Exception ignored){}return null;}

    private void showLogin(){
        final EditText pass=new EditText(this); pass.setInputType(0x81); pass.setHint("Парол");
        LinearLayout box=box(18); box.addView(text("Журнали Ман",23,navy,true)); box.addView(text("Паролро ворид кунед",15,Color.DKGRAY,false)); box.addView(pass);
        final AlertDialog d=new AlertDialog.Builder(this).setView(box).setCancelable(false).setPositiveButton("Даромадан",null).setNegativeButton("Баромадан",(x,w)->finish()).create();
        d.setOnShowListener(x->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(PASSWORD.equals(pass.getText().toString())){d.dismiss();buildMain();}else{pass.setError("Парол нодуруст аст");}});}); d.show();
    }

    @Override public void onWindowFocusChanged(boolean h){super.onWindowFocusChanged(h);}

    private void buildMain(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.VERTICAL);header.setPadding(22,24,16,16);header.setBackgroundColor(navy);
        TextView title=text("📚  Журнали Ман",25,Color.WHITE,true);header.addView(title);
        root.addView(header,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);controls.setPadding(12,12,12,4);controls.setBackgroundColor(light);
        LinearLayout r1=row(); classSpinner=new Spinner(this);r1.addView(label("Синф:"));r1.addView(classSpinner,new LinearLayout.LayoutParams(0,52,1));Button cls=button("Синфҳо",navy);r1.addView(cls,new LinearLayout.LayoutParams(100,52));controls.addView(r1);cls.setOnClickListener(v->manageClasses());
        LinearLayout r2=row();dateView=text("",17,navy,true);Button db=button("📅  Сана",blue);r2.addView(dateView,new LinearLayout.LayoutParams(0,52,1));r2.addView(db,new LinearLayout.LayoutParams(105,52));controls.addView(r2);db.setOnClickListener(v->pickDate());
        LinearLayout r3=row();r3.addView(label("Дарс:"));lessonSpinner=new Spinner(this);r3.addView(lessonSpinner,new LinearLayout.LayoutParams(0,52,1));Button rep=button("Ҳисобот",green);r3.addView(rep,new LinearLayout.LayoutParams(115,52));controls.addView(r3);rep.setOnClickListener(v->monthlyReport());
        LinearLayout r4=row();Button students=button("👥 Хонандагон",navy);Button backup=button("💾 Нусха",Color.DKGRAY);Button restore=button("↩ Барқарор",Color.DKGRAY);r4.addView(students,new LinearLayout.LayoutParams(0,48,1));r4.addView(backup,new LinearLayout.LayoutParams(0,48,1));r4.addView(restore,new LinearLayout.LayoutParams(0,48,1));controls.addView(r4);students.setOnClickListener(v->manageStudents());backup.setOnClickListener(v->backup());restore.setOnClickListener(v->restore());
        root.addView(controls);emptyView=text("",15,Color.DKGRAY,false);root.addView(emptyView,new LinearLayout.LayoutParams(-1,40));
        ScrollView sv=new ScrollView(this);studentsBox=new LinearLayout(this);studentsBox.setOrientation(LinearLayout.VERTICAL);studentsBox.setPadding(10,0,10,20);sv.addView(studentsBox);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setupSpinners();refresh();
    }
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);l.setPadding(0,2,0,2);return l;}
    private LinearLayout box(int p){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(p,p,p,p);return l;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(6,2,6,2);return t;}
    private TextView label(String s){return text(s,15,Color.DKGRAY,true);}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(Color.WHITE);b.setBackgroundColor(color);return b;}

    private void setupSpinners(){
        ArrayList<String> names=new ArrayList<>();classIds.clear();try{JSONArray a=state.getJSONArray("classes");for(int i=0;i<a.length();i++){JSONObject c=a.getJSONObject(i);classIds.add(c.getString("id"));names.add(c.getString("name"));}}catch(Exception ignored){}
        ArrayAdapter<String> ca=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names);classSpinner.setAdapter(ca);int ix=Math.max(0,classIds.indexOf(currentClassId));classSpinner.setSelection(ix);classSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){if(pos<classIds.size()){currentClassId=classIds.get(pos);try{state.put("currentClass",currentClassId);}catch(Exception ignored){}save();refresh();}}});
        updateLessons();
    }
    private int lessonsFor(String ddmmyyyy){try{Date d=new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(ddmmyyyy);Calendar c=Calendar.getInstance();c.setTime(d);int w=c.get(Calendar.DAY_OF_WEEK);if(w==Calendar.SUNDAY)return 0;if(w==Calendar.SATURDAY)return 3;if(w==Calendar.TUESDAY||w==Calendar.THURSDAY)return 6;return 7;}catch(Exception e){return 7;}}
    private void updateLessons(){int n=lessonsFor(selectedDate);ArrayList<String> a=new ArrayList<>();for(int i=1;i<=n;i++)a.add("Соати "+i);ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a);lessonSpinner.setAdapter(ad);if(n>0){selectedLesson=Math.min(selectedLesson,n);lessonSpinner.setSelection(selectedLesson-1);}lessonSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){selectedLesson=pos+1;refresh();}});}
    private void refresh(){if(studentsBox==null)return;dateView.setText(selectedDate);int n=lessonsFor(selectedDate);emptyView.setText(n==0?"Якшанбе — дарс нест":"Барои ҳар хонанда танҳо ғоибӣ қайд мешавад; бе тугма = ҳозир");studentsBox.removeAllViews();JSONObject c=currentClass();if(c==null)return;try{JSONArray ss=c.getJSONArray("students");for(int i=0;i<ss.length();i++)addStudentRow(ss.getJSONObject(i),i+1);}catch(Exception ignored){}}
    private void addStudentRow(JSONObject st,int num){
        String sid=st.optString("id"),name=st.optString("name");LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(4,5,2,5);r.setBackgroundColor(num%2==0?Color.rgb(248,250,253):Color.WHITE);
        TextView no=text(num+".",15,Color.GRAY,true);r.addView(no,new LinearLayout.LayoutParams(34,58));TextView nm=text(name,15,Color.rgb(25,35,45),false);r.addView(nm,new LinearLayout.LayoutParams(0,58,1));
        Button sb=button("СБ",Color.rgb(117,117,117));Button bsb=button("БСБ",Color.rgb(117,117,117));r.addView(sb,new LinearLayout.LayoutParams(58,52));r.addView(bsb,new LinearLayout.LayoutParams(64,52));
        String status=getStatus(sid);if("SB".equals(status)){sb.setBackgroundColor(Color.rgb(245,166,35));bsb.setBackgroundColor(Color.rgb(117,117,117));}else if("BSB".equals(status)){bsb.setBackgroundColor(Color.rgb(198,40,40));sb.setBackgroundColor(Color.rgb(117,117,117));}
        sb.setOnClickListener(v->{if("SB".equals(getStatus(sid))){clearStatus(sid);}else{setSB(sid);}refresh();});bsb.setOnClickListener(v->{if("BSB".equals(getStatus(sid))){clearStatus(sid);}else{setBSB(sid);}refresh();});
        studentsBox.addView(r);View line=new View(this);line.setBackgroundColor(Color.rgb(225,230,235));studentsBox.addView(line,new LinearLayout.LayoutParams(-1,1));
    }
    private JSONObject attendance(){try{return state.getJSONObject("attendance");}catch(Exception e){try{JSONObject a=new JSONObject();state.put("attendance",a);return a;}catch(Exception x){return new JSONObject();}}}
    private String attKey(String sid){return currentClassId+"|"+keyDate()+"|"+sid;}
    private String getStatus(String sid){return attendance().optString(attKey(sid),"");}
    private void clearStatus(String sid){attendance().remove(attKey(sid));save();}
    private void setBSB(String sid){try{JSONObject a=attendance();JSONObject x=new JSONObject();x.put("status","BSB");x.put("reason","");a.put(attKey(sid),x.toString());save();}catch(Exception ignored){}}
    private void setSB(String sid){
        final String[] reasons={"Беморӣ","Оилавӣ","Сабаби расмӣ","Дигар"};new AlertDialog.Builder(this).setTitle("Сабаби СБ-ро интихоб кунед").setItems(reasons,(d,w)->{if(w==3)customReason(sid);else saveSB(sid,reasons[w]);}).setNegativeButton("Бекор",null).show();
    }
    private void customReason(String sid){final EditText e=new EditText(this);e.setHint("Сабабро нависед");new AlertDialog.Builder(this).setTitle("Сабаби СБ").setView(e).setPositiveButton("Захира",(d,w)->saveSB(sid,e.getText().toString().trim().isEmpty()?"Дигар":e.getText().toString().trim())).setNegativeButton("Бекор",null).show();}
    private void saveSB(String sid,String reason){try{JSONObject a=attendance();JSONObject x=new JSONObject();x.put("status","SB");x.put("reason",reason);a.put(attKey(sid),x.toString());save();refresh();}catch(Exception ignored){}}

    private void pickDate(){Calendar c=Calendar.getInstance();try{c.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}new DatePickerDialog(this,(v,y,m,d)->{selectedDate=String.format(Locale.getDefault(),"%02d.%02d.%04d",d,m+1,y);selectedLesson=1;updateLessons();refresh();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}

    private void manageClasses(){
        LinearLayout l=box(12); JSONArray a; try{a=state.getJSONArray("classes");}catch(Exception e){return;}
        for(int i=0;i<a.length();i++){final JSONObject c=a.optJSONObject(i);if(c==null)continue;LinearLayout r=row();TextView n=text(c.optString("name"),17,navy,true);r.addView(n,new LinearLayout.LayoutParams(0,52,1));Button open=button("Кушодан",blue);Button del=button("Нест",red);r.addView(open,new LinearLayout.LayoutParams(90,48));r.addView(del,new LinearLayout.LayoutParams(70,48));l.addView(r);
            open.setOnClickListener(v->{currentClassId=c.optString("id");try{state.put("currentClass",currentClassId);}catch(Exception ignored){}save();buildMain();}); del.setOnClickListener(v->deleteClass(c.optString("id")));}
        Button add=button("＋ Иловаи синф",green);l.addView(add);add.setOnClickListener(v->addClassDialog());
        new AlertDialog.Builder(this).setTitle("Синфҳо").setView(l).setNegativeButton("Пӯшидан",null).show();
    }
    private void deleteClass(String cid){try{JSONArray a=state.getJSONArray("classes");if(a.length()<=1){toast("Камаш як синф бояд бошад");return;}new AlertDialog.Builder(this).setTitle("Нест кардани синф?").setMessage("Ҳамаи маълумоти ҳамин синф нест мешавад.").setPositiveButton("Нест",(d,w)->{for(int i=0;i<a.length();i++)if(a.optJSONObject(i).optString("id").equals(cid)){a.remove(i);break;}if(currentClassId.equals(cid))currentClassId=a.optJSONObject(0).optString("id");state.put("currentClass",currentClassId);save();buildMain();manageClasses();}).setNegativeButton("Бекор",null).show();}catch(Exception ignored){}}
    private void addClassDialog(){final EditText e=new EditText(this);e.setHint("Масалан: 9 «А»");new AlertDialog.Builder(this).setTitle("Синфи нав").setView(e).setPositiveButton("Илова",(d,w)->{String n=e.getText().toString().trim();if(n.isEmpty())return;try{JSONObject c=new JSONObject();String id=id();c.put("id",id);c.put("name",n);c.put("students",new JSONArray());state.getJSONArray("classes").put(c);currentClassId=id;state.put("currentClass",id);save();buildMain();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}

    private void manageStudents(){
        JSONObject c=currentClass();if(c==null)return;LinearLayout l=box(8);try{JSONArray a=c.getJSONArray("students");for(int i=0;i<a.length();i++){JSONObject s=a.getJSONObject(i);final int idx=i;LinearLayout r=row();r.addView(text((i+1)+". "+s.optString("name"),15,Color.DKGRAY,false),new LinearLayout.LayoutParams(0,50,1));Button edit=button("Таҳрир",blue);Button del=button("Нест",red);r.addView(edit,new LinearLayout.LayoutParams(78,46));r.addView(del,new LinearLayout.LayoutParams(70,46));l.addView(r);edit.setOnClickListener(v->editStudent(idx));del.setOnClickListener(v->deleteStudent(idx));}}catch(Exception ignored){}Button add=button("＋ Иловаи хонанда",green);l.addView(add);add.setOnClickListener(v->addStudent());ScrollView sv=new ScrollView(this);sv.addView(l);new AlertDialog.Builder(this).setTitle("Хонандагони "+c.optString("name")).setView(sv).setPositiveButton("Пӯшидан",null).setNeutralButton("Синфро холӣ кардан",(d,w)->clearStudents()).show();}
    private void addStudent(){final EditText e=new EditText(this);e.setHint("Ному насаб");new AlertDialog.Builder(this).setTitle("Хонандаи нав").setView(e).setPositiveButton("Илова",(d,w)->{try{String n=e.getText().toString().trim();if(n.isEmpty())return;JSONObject s=new JSONObject();s.put("id",id());s.put("name",n);currentClass().getJSONArray("students").put(s);save();refresh();manageStudents();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}
    private void editStudent(int idx){final EditText e=new EditText(this);try{e.setText(currentClass().getJSONArray("students").getJSONObject(idx).optString("name"));}catch(Exception ignored){}new AlertDialog.Builder(this).setTitle("Таҳрири ном").setView(e).setPositiveButton("Захира",(d,w)->{try{String n=e.getText().toString().trim();if(!n.isEmpty()){currentClass().getJSONArray("students").getJSONObject(idx).put("name",n);save();refresh();manageStudents();}}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}
    private void deleteStudent(int idx){new AlertDialog.Builder(this).setTitle("Нест кардани хонанда?").setMessage("Давомоти дигар хонандагон тағйир намеёбад.").setPositiveButton("Нест",(d,w)->{try{currentClass().getJSONArray("students").remove(idx);save();refresh();manageStudents();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}
    private void clearStudents(){new AlertDialog.Builder(this).setTitle("Рӯйхатро холӣ кунам?").setMessage("Номҳои синфи ҷорӣ нест мешаванд. Синфҳои дигар бетағйир мемонанд.").setPositiveButton("Холӣ кун",(d,w)->{try{currentClass().put("students",new JSONArray());save();refresh();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}

    private void monthlyReport(){
        Calendar now=Calendar.getInstance();
        try{now.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}
        int month=now.get(Calendar.MONTH),year=now.get(Calendar.YEAR);
        final String[] months={"Январ","Феврал","Март","Апрел","Май","Июн","Июл","Август","Сентябр","Октябр","Ноябр","Декабр"};
        LinearLayout l=box(12);
        TextView info=text("Синф: "+currentClass().optString("name")+"\nДавра: "+months[month]+" "+year,17,navy,true);
        l.addView(info);
        l.addView(text("Ҳисобот танҳо ғоибии хонандагонро нишон медиҳад.",14,Color.DKGRAY,false));
        l.addView(text("СБ = бо сабаб   •   БСБ = бесабаб",14,Color.DKGRAY,false));
        l.addView(text("────────────────────────────────",13,Color.LTGRAY,false));
        int classSB=0,classBSB=0;
        try{
            Calendar c=Calendar.getInstance(); c.set(year,month,1); int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);
            JSONArray ss=currentClass().getJSONArray("students");
            for(int i=0;i<ss.length();i++){
                JSONObject st=ss.getJSONObject(i); int sb=0,bsb=0; HashMap<String,Integer> rs=new LinkedHashMap<>();
                for(int d=1;d<=days;d++){
                    c.set(year,month,d); int w=c.get(Calendar.DAY_OF_WEEK);
                    int n=(w==Calendar.SUNDAY)?0:(w==Calendar.SATURDAY?3:((w==Calendar.TUESDAY||w==Calendar.THURSDAY)?6:7));
                    for(int les=1;les<=n;les++){
                        String date=String.format(Locale.getDefault(),"%02d.%02d.%04d",d,month+1,year);
                        String val=attendance().optString(currentClassId+"|"+date+"|"+les+"|"+st.optString("id"));
                        if(val.isEmpty())continue;
                        try{JSONObject x=new JSONObject(val); String status=x.optString("status");
                            if("SB".equals(status)){sb++; classSB++; String reason=x.optString("reason","Дигар"); rs.put(reason,rs.containsKey(reason)?rs.get(reason)+1:1);}
                            else if("BSB".equals(status)){bsb++; classBSB++;}
                        }catch(Exception ignored){}
                    }
                }
                int total=sb+bsb;
                LinearLayout card=box(6);
                TextView name=text((i+1)+". "+st.optString("name"),15,navy,true); card.addView(name);
                TextView counts=text("СБ: "+sb+"    БСБ: "+bsb+"    Ҳамагӣ: "+total,14,Color.DKGRAY,false); card.addView(counts);
                if(!rs.isEmpty()){StringBuilder reasons=new StringBuilder("Сабаб: "); for(Map.Entry<String,Integer> e:rs.entrySet())reasons.append(e.getKey()).append(" (").append(e.getValue()).append(")  "); card.addView(text(reasons.toString(),12,Color.GRAY,false));}
                card.setBackgroundColor(i%2==0?Color.rgb(248,250,253):Color.WHITE); l.addView(card);
            }
            l.addView(text("────────────────────────────────",13,Color.LTGRAY,false));
            l.addView(text("ҶАМЪИ СИНФ:   СБ = "+classSB+"    БСБ = "+classBSB+"    ҲАМАГӢ = "+(classSB+classBSB),16,navy,true));
        }catch(Exception ignored){}
        ScrollView sv=new ScrollView(this); sv.addView(l);
        new AlertDialog.Builder(this).setTitle("Ҳисоботи ғоибӣ").setView(sv).setPositiveButton("Пӯшидан",null).show();
    }

    private void backup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Jurnali_Man_Backup.json");startActivityForResult(i,10);}
    private void restore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,11);}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(c!=RESULT_OK||data==null)return;try{if(r==10){OutputStream o=getContentResolver().openOutputStream(data.getData());o.write(state.toString(2).getBytes("UTF-8"));o.close();toast("Нусха захира шуд");}else if(r==11){InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)b.write(buf,0,n);in.close();JSONObject x=new JSONObject(new String(b.toByteArray(),"UTF-8"));if(!x.has("classes")||!x.has("attendance"))throw new Exception();state=x;currentClassId=state.optString("currentClass",firstClassId());save();buildMain();toast("Маълумот барқарор шуд");}}catch(Exception e){toast("Файл дуруст нест");}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
