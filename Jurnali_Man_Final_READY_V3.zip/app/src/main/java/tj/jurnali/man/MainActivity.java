package tj.jurnali.man;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    private static final String PREFS="journal_prefs", KEY="state", PASSWORD="12345678";
    private final String[] initialNames={
        "АЛИШУРОВ АБУБАКР","БАРАТОВА ЗИЁДА","БАРАТОВА МАДИНАБОНУ","БОБОНОЗАРОВА СОЛИҲА","ҒАНИЕВ СУНАТУЛЛО",
        "ЗАРИПОВА СОФИЯ","ИБРОҲИМЗОДА ГЕСУ","ИШИМОВ АБДУСАЛОМ","КАРИМОВ ХУРШЕД","ҚАҲОРОВ МУҲАММАД",
        "МАҲКАМОВ ИДРИС","МИНГБОЕВ БОБУР","МУХТОРОВ МУХАММАДЮСУФ","ОДИЛҶОНОВ ДЖАМОЛИДДИН","ОДИНАЕВ ИЛЁС",
        "ПИРОВ БОБУРҶОН","ПУЛАТОВ КОМРОН","РАҲИМОВ УБАЙДУЛЛО","РУЗИЕВ МУХАММАД","САИДОВ РАБОНИ",
        "САТТАРОВ ОТАҶОН","ТУРСУНОВА ШУКРОНА","УМАРОВ ФАРРУХ","ХАМРОЕВ БАРАКАТУЛЛО","ХОЛБОЕВА МЕҲРИНУШ",
        "ХОЛОВ АБДУЛЛО","ХУДОЁРОВ ҲАСАН","ШЕРОВ САИДАҲМАДХОН","БЕРДИМУРАТОВ АЗИМҶОН","НАЗАРОВА ОСИЁ"
    };
    private JSONObject state; private String currentClassId; private String selectedDate; private int selectedLesson=1;
    private LinearLayout root, studentsBox; private Spinner classSpinner, lessonSpinner; private TextView dateView, infoView, statsView;
    private ArrayList<String> classIds=new ArrayList<>();
    private final int navy=Color.rgb(11,49,77), blue=Color.rgb(30,136,229), red=Color.rgb(220,38,54), green=Color.rgb(22,150,83);
    private final int page=Color.rgb(246,249,252), textDark=Color.rgb(20,45,70), muted=Color.rgb(95,111,126);

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(7,38,61)); getWindow().setNavigationBarColor(Color.rgb(7,31,48)); loadState(); selectedDate=today(); showLogin();}
    private String today(){return new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new Date());}
    private String keyDate(){return selectedDate+"|"+selectedLesson;}
    private void loadState(){
        String s=getSharedPreferences(PREFS,0).getString(KEY,null);
        try { state=s==null?createInitial():new JSONObject(s); } catch(Exception e){state=createInitial();}
        try{currentClassId=state.getString("currentClass");}catch(Exception e){currentClassId=firstClassId();}
        save();
    }
    private JSONObject createInitial(){
        JSONObject st=new JSONObject(); JSONArray classes=new JSONArray(); JSONObject c=new JSONObject();
        try{String cid=id(); c.put("id",cid); c.put("name","8 «В»"); JSONArray ss=new JSONArray(); for(String n:initialNames){JSONObject x=new JSONObject();x.put("id",id());x.put("name",n);ss.put(x);} c.put("students",ss); classes.put(c); st.put("classes",classes); st.put("attendance",new JSONObject()); st.put("currentClass",cid);}catch(Exception ignored){} return st;
    }
    private String id(){return System.currentTimeMillis()+"_"+UUID.randomUUID().toString().substring(0,8);}
    private void save(){getSharedPreferences(PREFS,0).edit().putString(KEY,state.toString()).apply();}
    private String firstClassId(){try{return state.getJSONArray("classes").getJSONObject(0).getString("id");}catch(Exception e){return "";}}
    private JSONObject currentClass(){try{JSONArray a=state.getJSONArray("classes");for(int i=0;i<a.length();i++){JSONObject c=a.getJSONObject(i);if(c.getString("id").equals(currentClassId))return c;}}catch(Exception ignored){}return null;}

    private void showLogin(){
        final EditText pass=new EditText(this); pass.setInputType(0x81); pass.setHint("Парол");
        LinearLayout box=box(20); TextView title=text("ЛБХБ ТУРСУНЗОДА",23,navy,true); title.setGravity(Gravity.CENTER); box.addView(title,new LinearLayout.LayoutParams(-1,58));
        TextView sub=text("Ба барномаи давомоти синф дароед",15,muted,false); sub.setGravity(Gravity.CENTER); box.addView(sub,new LinearLayout.LayoutParams(-1,42)); box.addView(pass);
        final AlertDialog d=new AlertDialog.Builder(this).setView(box).setCancelable(false).setPositiveButton("Даромадан",null).setNegativeButton("Баромадан",(x,w)->finish()).create();
        d.setOnShowListener(x->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(PASSWORD.equals(pass.getText().toString())){d.dismiss();buildMain();}else pass.setError("Парол нодуруст аст");});}); d.show();
    }

    private void buildMain(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(page);
        setContentView(root);

        // Android 15+ draws edge-to-edge. Keep the fixed header and bottom navigation
        // clear of the status/navigation bars; only the student list scrolls.
        root.setOnApplyWindowInsetsListener((v,insets)->{
            int top=0,bottom=0;
            if(android.os.Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
                top=bars.top; bottom=bars.bottom;
            }else{
                top=insets.getSystemWindowInsetTop(); bottom=insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0,top,0,bottom);
            return insets;
        });
        root.requestApplyInsets();

        // Fixed compact header. Application name is intentionally not shown.
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(10,0,8,0); header.setBackgroundColor(navy);
        TextView icon=text("🎓",25,Color.WHITE,false); icon.setGravity(Gravity.CENTER);
        header.addView(icon,new LinearLayout.LayoutParams(48,54));
        TextView school=text("ЛБХБ ТУРСУНЗОДА",19,Color.WHITE,true); school.setGravity(Gravity.CENTER_VERTICAL);
        school.setMaxLines(1); school.setEllipsize(android.text.TextUtils.TruncateAt.END);
        header.addView(school,new LinearLayout.LayoutParams(0,54,1));
        TextView more=text("⋮",28,Color.WHITE,true); more.setGravity(Gravity.CENTER);
        header.addView(more,new LinearLayout.LayoutParams(38,54));
        root.addView(header,new LinearLayout.LayoutParams(-1,54));

        // Compact fixed controls.
        LinearLayout controls=new LinearLayout(this); controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(8,5,8,2);

        LinearLayout r1=row();
        classSpinner=new Spinner(this); styleSpinner(classSpinner);
        r1.addView(classSpinner,new LinearLayout.LayoutParams(0,42,1));
        Button cls=smallAction("Синф",navy); r1.addView(cls,new LinearLayout.LayoutParams(70,42));
        controls.addView(r1); cls.setOnClickListener(v->manageClasses());

        LinearLayout r2=row();
        dateView=text("",16,textDark,true); dateView.setGravity(Gravity.CENTER_VERTICAL);
        r2.addView(dateView,new LinearLayout.LayoutParams(0,42,1));
        Button db=smallAction("📅 Сана",blue); r2.addView(db,new LinearLayout.LayoutParams(88,42));
        controls.addView(r2); db.setOnClickListener(v->pickDate());

        LinearLayout r3=row();
        TextView dl=text("Дарс",14,muted,true); r3.addView(dl,new LinearLayout.LayoutParams(45,42));
        lessonSpinner=new Spinner(this); styleSpinner(lessonSpinner);
        r3.addView(lessonSpinner,new LinearLayout.LayoutParams(0,42,1));
        controls.addView(r3);
        root.addView(controls,new LinearLayout.LayoutParams(-1,134));

        LinearLayout summary=row(); summary.setPadding(8,1,8,4);
        infoView=text("",12,muted,false); infoView.setMaxLines(1); infoView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        summary.addView(infoView,new LinearLayout.LayoutParams(0,36,1));
        statsView=text("",12,textDark,true); statsView.setGravity(Gravity.CENTER); statsView.setMaxLines(1);
        statsView.setBackground(round(Color.WHITE,Color.rgb(222,230,238),15));
        summary.addView(statsView,new LinearLayout.LayoutParams(185,36));
        root.addView(summary,new LinearLayout.LayoutParams(-1,40));

        // ONLY this area scrolls. Header, controls and bottom navigation stay fixed.
        ScrollView sv=new ScrollView(this); sv.setFillViewport(false); sv.setClipToPadding(true);
        studentsBox=new LinearLayout(this); studentsBox.setOrientation(LinearLayout.VERTICAL);
        studentsBox.setPadding(7,1,7,8); sv.addView(studentsBox);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        root.addView(buildBottomBar(),new LinearLayout.LayoutParams(-1,76));
        setupSpinners(); refresh();
    }

    private LinearLayout buildBottomBar(){
        LinearLayout bottom=new LinearLayout(this); bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER); bottom.setPadding(5,4,5,5);
        bottom.setBackground(round(Color.rgb(8,43,68),Color.rgb(8,43,68),26));
        bottom.addView(navItem("⌂","Қайд",blue,v->{if(studentsBox!=null)studentsBox.requestFocus();}),weight());
        bottom.addView(navItem("▥","Ҳисобот",Color.WHITE,v->monthlyReport()),weight());
        bottom.addView(navItem("▦","Excel",Color.WHITE,v->exportExcel()),weight());
        bottom.addView(navItem("▣","Backup",Color.WHITE,v->backup()),weight());
        bottom.addView(navItem("♻","Restore",Color.WHITE,v->restore()),weight());
        return bottom;
    }
    private LinearLayout navItem(String ico,String label,int activeColor,View.OnClickListener click){
        LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
        item.setPadding(1,1,1,1);
        TextView i=text(ico,21,activeColor,true); i.setGravity(Gravity.CENTER);
        TextView t=text(label,9,activeColor,true); t.setGravity(Gravity.CENTER); t.setMaxLines(1);
        item.addView(i,new LinearLayout.LayoutParams(-1,34)); item.addView(t,new LinearLayout.LayoutParams(-1,25));
        if("Қайд".equals(label)){i.setBackground(round(Color.rgb(15,83,127),Color.rgb(15,83,127),28));}
        item.setOnClickListener(click); return item;
    }
    private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,65,1);}

    private void styleSpinner(Spinner s){s.setBackground(round(Color.WHITE,Color.rgb(215,225,234),18)); s.setPadding(10,0,10,0);}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(radius);if(stroke!=fill)g.setStroke(1,stroke);return g;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout box(int p){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(p,p,p,p);return l;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(5,2,5,2);return t;}
    private Button smallAction(String s,int color){Button b=button(s,13,Color.WHITE);b.setBackground(round(color,color,17));return b;}
    private Button button(String s,int size,int color){Button b=new Button(this);b.setText(s);b.setTextSize(size);b.setTextColor(color);b.setGravity(Gravity.CENTER);b.setAllCaps(false);b.setPadding(0,0,0,0);return b;}

    private void setupSpinners(){
        ArrayList<String> names=new ArrayList<>();classIds.clear();try{JSONArray a=state.getJSONArray("classes");for(int i=0;i<a.length();i++){JSONObject c=a.getJSONObject(i);classIds.add(c.getString("id"));names.add("Синф: "+c.getString("name"));}}catch(Exception ignored){}
        ArrayAdapter<String> ca=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names);classSpinner.setAdapter(ca);int ix=Math.max(0,classIds.indexOf(currentClassId));classSpinner.setSelection(ix);classSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(pos<classIds.size()){currentClassId=classIds.get(pos);try{state.put("currentClass",currentClassId);}catch(Exception ignored){}save();refresh();}}}); updateLessons();
    }
    private int lessonsFor(String ddmmyyyy){try{Date d=new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(ddmmyyyy);Calendar c=Calendar.getInstance();c.setTime(d);int w=c.get(Calendar.DAY_OF_WEEK);if(w==Calendar.SUNDAY)return 0;if(w==Calendar.SATURDAY)return 3;if(w==Calendar.TUESDAY||w==Calendar.THURSDAY)return 6;return 7;}catch(Exception e){return 7;}}
    private void updateLessons(){int n=lessonsFor(selectedDate);ArrayList<String> a=new ArrayList<>();for(int i=1;i<=n;i++)a.add("Соати "+i);ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a);lessonSpinner.setAdapter(ad);if(n>0){selectedLesson=Math.min(selectedLesson,n);lessonSpinner.setSelection(selectedLesson-1);}lessonSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int pos,long id){selectedLesson=pos+1;refresh();}});}

    private void refresh(){
        if(studentsBox==null)return; dateView.setText(selectedDate); JSONObject c=currentClass(); if(c==null)return; int n=lessonsFor(selectedDate); infoView.setText(n==0?"Якшанбе — дарс нест":"Танҳо ғоибӣ қайд мешавад • Соати "+selectedLesson);
        studentsBox.removeAllViews(); int sbc=0,bsbc=0,total=0; try{JSONArray ss=c.getJSONArray("students"); for(int i=0;i<ss.length();i++){String st=getStatus(ss.getJSONObject(i).optString("id"));if("SB".equals(st)){sbc++;total++;}else if("BSB".equals(st)){bsbc++;total++;} addStudentRow(ss.getJSONObject(i),i+1);}}catch(Exception ignored){} statsView.setText("Ҳама: "+(c.optJSONArray("students")==null?0:c.optJSONArray("students").length())+"   |   СБ "+sbc+"   |   БСБ "+bsbc);
    }
    private void addStudentRow(JSONObject st,int num){
        String sid=st.optString("id"),name=st.optString("name"); String status=getStatus(sid);
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(4,2,3,2);
        int bg="SB".equals(status)?Color.rgb(231,249,239):("BSB".equals(status)?Color.rgb(255,235,238):Color.WHITE);
        card.setBackground(round(bg,bg,12));

        TextView no=text(String.valueOf(num),14,muted,true); no.setGravity(Gravity.CENTER);
        card.addView(no,new LinearLayout.LayoutParams(32,54));

        int nameColor="SB".equals(status)?green:("BSB".equals(status)?red:textDark);
        TextView nm=text(name,15,nameColor,"SB".equals(status)||"BSB".equals(status));
        nm.setMaxLines(1); nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(nm,new LinearLayout.LayoutParams(0,54,1));

        Button sb=attendanceButton("СБ",green,"SB".equals(status));
        Button bsb=attendanceButton("БСБ",red,"BSB".equals(status));
        card.addView(sb,new LinearLayout.LayoutParams(58,50));
        Space gap=new Space(this); card.addView(gap,new LinearLayout.LayoutParams(3,1));
        card.addView(bsb,new LinearLayout.LayoutParams(62,50));

        sb.setOnClickListener(v->{if("SB".equals(getStatus(sid))){clearStatus(sid);refresh();}else setSB(sid);});
        bsb.setOnClickListener(v->{if("BSB".equals(getStatus(sid))){clearStatus(sid);refresh();}else{setBSB(sid);refresh();}});

        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,58); cp.setMargins(0,1,0,1); studentsBox.addView(card,cp);
    }
    private Button attendanceButton(String s,int color,boolean selected){
        Button b=button(s,17,selected?Color.WHITE:color); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setMinHeight(50); b.setMinWidth(58);
        b.setBackground(round(selected?color:Color.WHITE,color,14)); return b;
    }
    private JSONObject attendance(){try{return state.getJSONObject("attendance");}catch(Exception e){try{JSONObject a=new JSONObject();state.put("attendance",a);return a;}catch(Exception x){return new JSONObject();}}}
    private String attKey(String sid){return currentClassId+"|"+keyDate()+"|"+sid;}
    private String getStatus(String sid){String val=attendance().optString(attKey(sid),"");try{return new JSONObject(val).optString("status","");}catch(Exception e){return "";}}
    private String getReason(String sid){String val=attendance().optString(attKey(sid),"");try{return new JSONObject(val).optString("reason","");}catch(Exception e){return "";}}
    private void clearStatus(String sid){attendance().remove(attKey(sid));save();}
    private void setBSB(String sid){try{JSONObject x=new JSONObject();x.put("status","BSB");x.put("reason","");attendance().put(attKey(sid),x.toString());save();}catch(Exception ignored){}}
    private void setSB(String sid){final String[] reasons={"Беморӣ","Оилавӣ","Сабаби расмӣ","Дигар"};new AlertDialog.Builder(this).setTitle("Сабаби СБ").setItems(reasons,(d,w)->{if(w==3)customReason(sid);else saveSB(sid,reasons[w]);}).setNegativeButton("Бекор",null).show();}
    private void customReason(String sid){final EditText e=new EditText(this);e.setHint("Сабабро нависед");new AlertDialog.Builder(this).setTitle("Сабаби СБ").setView(e).setPositiveButton("Захира",(d,w)->saveSB(sid,e.getText().toString().trim().isEmpty()?"Дигар":e.getText().toString().trim())).setNegativeButton("Бекор",null).show();}
    private void saveSB(String sid,String reason){try{JSONObject x=new JSONObject();x.put("status","SB");x.put("reason",reason);attendance().put(attKey(sid),x.toString());save();refresh();}catch(Exception ignored){}}

    private void pickDate(){Calendar c=Calendar.getInstance();try{c.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}new DatePickerDialog(this,(v,y,m,d)->{selectedDate=String.format(Locale.getDefault(),"%02d.%02d.%04d",d,m+1,y);selectedLesson=1;updateLessons();refresh();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}

    private void manageClasses(){LinearLayout l=box(12);JSONArray a;try{a=state.getJSONArray("classes");}catch(Exception e){return;}for(int i=0;i<a.length();i++){final JSONObject c=a.optJSONObject(i);if(c==null)continue;LinearLayout r=row();TextView n=text(c.optString("name"),17,navy,true);r.addView(n,new LinearLayout.LayoutParams(0,52,1));Button open=smallAction("Кушодан",blue);Button del=smallAction("Нест",red);r.addView(open,new LinearLayout.LayoutParams(90,48));r.addView(del,new LinearLayout.LayoutParams(70,48));l.addView(r);open.setOnClickListener(v->{currentClassId=c.optString("id");try{state.put("currentClass",currentClassId);}catch(Exception ignored){}save();buildMain();});del.setOnClickListener(v->deleteClass(c.optString("id")));}Button add=smallAction("＋ Иловаи синф",green);l.addView(add);add.setOnClickListener(v->addClassDialog());new AlertDialog.Builder(this).setTitle("Синфҳо").setView(l).setNegativeButton("Пӯшидан",null).show();}
    private void deleteClass(String cid){try{JSONArray a=state.getJSONArray("classes");if(a.length()<=1){toast("Камаш як синф бояд бошад");return;}new AlertDialog.Builder(this).setTitle("Нест кардани синф?").setMessage("Ҳамаи маълумоти ҳамин синф нест мешавад.").setPositiveButton("Нест",(d,w)->{for(int i=0;i<a.length();i++)if(a.optJSONObject(i).optString("id").equals(cid)){a.remove(i);break;}if(currentClassId.equals(cid))currentClassId=a.optJSONObject(0).optString("id");try{state.put("currentClass",currentClassId);}catch(Exception ignored){}save();buildMain();}).setNegativeButton("Бекор",null).show();}catch(Exception ignored){}}
    private void addClassDialog(){final EditText e=new EditText(this);e.setHint("Масалан: 9 «А»");new AlertDialog.Builder(this).setTitle("Синфи нав").setView(e).setPositiveButton("Илова",(d,w)->{String n=e.getText().toString().trim();if(n.isEmpty())return;try{JSONObject c=new JSONObject();String cid=id();c.put("id",cid);c.put("name",n);c.put("students",new JSONArray());state.getJSONArray("classes").put(c);currentClassId=cid;state.put("currentClass",cid);save();buildMain();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}

    private void manageStudents(){JSONObject c=currentClass();if(c==null)return;LinearLayout l=box(8);try{JSONArray a=c.getJSONArray("students");for(int i=0;i<a.length();i++){JSONObject s=a.getJSONObject(i);final int idx=i;LinearLayout r=row();r.addView(text((i+1)+". "+s.optString("name"),15,Color.DKGRAY,false),new LinearLayout.LayoutParams(0,50,1));Button edit=smallAction("Таҳрир",blue);Button del=smallAction("Нест",red);r.addView(edit,new LinearLayout.LayoutParams(78,46));r.addView(del,new LinearLayout.LayoutParams(70,46));l.addView(r);edit.setOnClickListener(v->editStudent(idx));del.setOnClickListener(v->deleteStudent(idx));}}catch(Exception ignored){}Button add=smallAction("＋ Иловаи хонанда",green);l.addView(add);add.setOnClickListener(v->addStudent());ScrollView sv=new ScrollView(this);sv.addView(l);new AlertDialog.Builder(this).setTitle("Хонандагони "+c.optString("name")).setView(sv).setPositiveButton("Пӯшидан",null).setNeutralButton("Синфро холӣ кардан",(d,w)->clearStudents()).show();}
    private void addStudent(){final EditText e=new EditText(this);e.setHint("Ному насаб");new AlertDialog.Builder(this).setTitle("Хонандаи нав").setView(e).setPositiveButton("Илова",(d,w)->{try{String n=e.getText().toString().trim();if(n.isEmpty())return;JSONObject s=new JSONObject();s.put("id",id());s.put("name",n);currentClass().getJSONArray("students").put(s);save();refresh();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}
    private void editStudent(int idx){final EditText e=new EditText(this);try{e.setText(currentClass().getJSONArray("students").getJSONObject(idx).optString("name"));}catch(Exception ignored){}new AlertDialog.Builder(this).setTitle("Таҳрири ном").setView(e).setPositiveButton("Захира",(d,w)->{try{String n=e.getText().toString().trim();if(!n.isEmpty()){currentClass().getJSONArray("students").getJSONObject(idx).put("name",n);save();refresh();}}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}
    private void deleteStudent(int idx){new AlertDialog.Builder(this).setTitle("Нест кардани хонанда?").setMessage("Давомоти дигар хонандагон тағйир намеёбад.").setPositiveButton("Нест",(d,w)->{try{currentClass().getJSONArray("students").remove(idx);save();refresh();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}
    private void clearStudents(){new AlertDialog.Builder(this).setTitle("Рӯйхатро холӣ кунам?").setPositiveButton("Холӣ кун",(d,w)->{try{currentClass().put("students",new JSONArray());save();refresh();}catch(Exception ignored){}}).setNegativeButton("Бекор",null).show();}

    private int[] monthCounts(){
        int sb=0,bsb=0;Calendar now=Calendar.getInstance();try{now.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}
        int month=now.get(Calendar.MONTH),year=now.get(Calendar.YEAR);try{JSONArray ss=currentClass().getJSONArray("students");Calendar c=Calendar.getInstance();int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);for(int d=1;d<=days;d++){c.set(year,month,d);int w=c.get(Calendar.DAY_OF_WEEK);int n=(w==Calendar.SUNDAY)?0:(w==Calendar.SATURDAY?3:((w==Calendar.TUESDAY||w==Calendar.THURSDAY)?6:7));for(int les=1;les<=n;les++)for(int i=0;i<ss.length();i++){String sid=ss.getJSONObject(i).optString("id");String val=attendance().optString(currentClassId+"|"+String.format(Locale.getDefault(),"%02d.%02d.%04d",d,month+1,year)+"|"+les+"|"+sid,"");try{String st=new JSONObject(val).optString("status");if("SB".equals(st))sb++;else if("BSB".equals(st))bsb++;}catch(Exception ignored){}}}}catch(Exception ignored){}return new int[]{sb,bsb};
    }
    private String monthTitle(){Calendar now=Calendar.getInstance();try{now.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}String[] m={"Январ","Феврал","Март","Апрел","Май","Июн","Июл","Август","Сентябр","Октябр","Ноябр","Декабр"};return m[now.get(Calendar.MONTH)]+" "+now.get(Calendar.YEAR);}

    private void monthlyReport(){
        final String[] months={"Январ","Феврал","Март","Апрел","Май","Июн","Июл","Август","Сентябр","Октябр","Ноябр","Декабр"};Calendar now=Calendar.getInstance();try{now.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}int month=now.get(Calendar.MONTH),year=now.get(Calendar.YEAR);
        StringBuilder out=new StringBuilder("Синф: ").append(currentClass().optString("name")).append("\nМоҳ: ").append(months[month]).append(" ").append(year).append("\n\n№   Хонанда                         СБ    БСБ    Ҳамагӣ\n");
        int allSB=0,allBSB=0;try{JSONArray ss=currentClass().getJSONArray("students");for(int i=0;i<ss.length();i++){JSONObject s=ss.getJSONObject(i);int[] cnt=countStudentMonth(s.optString("id"),month,year);allSB+=cnt[0];allBSB+=cnt[1];out.append(String.format(Locale.getDefault(),"%-3d %-30s %4d %5d %7d\n",i+1,s.optString("name"),cnt[0],cnt[1],cnt[0]+cnt[1]));}}catch(Exception ignored){}out.append("\nҶамъ: СБ ").append(allSB).append(" | БСБ ").append(allBSB).append(" | Ҳамагӣ ").append(allSB+allBSB);
        TextView body=text(out.toString(),13,Color.DKGRAY,false);body.setTypeface(Typeface.MONOSPACE,Typeface.NORMAL);body.setPadding(8,8,8,8);ScrollView sv=new ScrollView(this);sv.addView(body);new AlertDialog.Builder(this).setTitle("Ҳисоботи моҳона").setView(sv).setPositiveButton("Пӯшидан",null).setNeutralButton("Excel",(d,w)->exportExcel()).show();
    }
    private int[] countStudentMonth(String sid,int month,int year){int sb=0,bsb=0;Calendar c=Calendar.getInstance();c.set(year,month,1);int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);for(int d=1;d<=days;d++){c.set(year,month,d);int w=c.get(Calendar.DAY_OF_WEEK);int n=(w==Calendar.SUNDAY)?0:(w==Calendar.SATURDAY?3:((w==Calendar.TUESDAY||w==Calendar.THURSDAY)?6:7));for(int les=1;les<=n;les++){String date=String.format(Locale.getDefault(),"%02d.%02d.%04d",d,month+1,year);try{String st=new JSONObject(attendance().optString(currentClassId+"|"+date+"|"+les+"|"+sid,"")).optString("status");if("SB".equals(st))sb++;else if("BSB".equals(st))bsb++;}catch(Exception ignored){}}}return new int[]{sb,bsb};}

    // Excel-compatible HTML workbook. Excel opens .xls directly and preserves the table structure.
    private void exportExcel(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/vnd.ms-excel");i.putExtra(Intent.EXTRA_TITLE,"Hisobot_"+safeFileName(currentClass().optString("name"))+"_"+safeFileName(monthTitle())+".xls");startActivityForResult(i,12);}
    private String safeFileName(String s){return s.replaceAll("[\\\\/:*?\"<>|]","_").replace(' ','_');}
    private String esc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    private String excelHtml(){
        StringBuilder h=new StringBuilder("<html><head><meta charset='UTF-8'></head><body>");h.append("<h2>Ҳисоботи ғоибии хонандагон</h2><p><b>Синф:</b> ").append(esc(currentClass().optString("name"))).append("<br><b>Моҳ:</b> ").append(esc(monthTitle())).append("</p><table border='1' cellspacing='0' cellpadding='6'><tr><th>№</th><th>Хонанда</th><th>СБ</th><th>БСБ</th><th>Ҳамагӣ</th></tr>");int a=0,b=0;try{JSONArray ss=currentClass().getJSONArray("students");Calendar now=Calendar.getInstance();try{now.setTime(new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).parse(selectedDate));}catch(Exception ignored){}int month=now.get(Calendar.MONTH),year=now.get(Calendar.YEAR);for(int i=0;i<ss.length();i++){JSONObject s=ss.getJSONObject(i);int[] cnt=countStudentMonth(s.optString("id"),month,year);a+=cnt[0];b+=cnt[1];h.append("<tr><td>").append(i+1).append("</td><td>").append(esc(s.optString("name"))).append("</td><td>").append(cnt[0]).append("</td><td>").append(cnt[1]).append("</td><td>").append(cnt[0]+cnt[1]).append("</td></tr>");}}catch(Exception ignored){}h.append("<tr><th colspan='2'>ҶАМЪ</th><th>").append(a).append("</th><th>").append(b).append("</th><th>").append(a+b).append("</th></tr></table></body></html>");return h.toString();
    }

    private void backup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Jurnali_Man_Backup.json");startActivityForResult(i,10);}
    private void restore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,11);}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(c!=RESULT_OK||data==null)return;try{if(r==10){OutputStream o=getContentResolver().openOutputStream(data.getData());o.write(state.toString(2).getBytes("UTF-8"));o.close();toast("Нусха захира шуд");}else if(r==11){InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)b.write(buf,0,n);in.close();JSONObject x=new JSONObject(new String(b.toByteArray(),"UTF-8"));if(!x.has("classes")||!x.has("attendance"))throw new Exception();state=x;currentClassId=state.optString("currentClass",firstClassId());save();buildMain();toast("Маълумот барқарор шуд");}else if(r==12){OutputStream o=getContentResolver().openOutputStream(data.getData());o.write(excelHtml().getBytes("UTF-8"));o.close();toast("Ҳисобот ба Excel гузашт");}}catch(Exception e){toast("Файл дуруст нест ё захира нашуд");}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
